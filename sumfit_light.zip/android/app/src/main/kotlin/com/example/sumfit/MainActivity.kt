package com.example.sumfit

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
