const String kOrganizerInviteCode = 'SUMFIT-ORG-2024';

const List<String> kFaculties = [
  'FPMOZ',
  'FSRE',
  'EF',
  'FF',
];
